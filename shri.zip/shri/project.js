$(function(){
	$(".library").fadeOut().slideDown(2000);
	$(".bt").fadeOut().slideDown(2000);
	$(".abc").fadeOut().slideDown(2000);
	$(".file").fadeOut().slideDown(2000);
	$(".regi").fadeOut().slideDown(2000);
	  $(".abc").fadeIn(3000);
});